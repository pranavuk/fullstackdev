// Get file input and gallery container
const imageInput = document.getElementById("imageInput");
const gallery = document.getElementById("gallery");

// When user selects images
imageInput.addEventListener("change", function() {

    const files = imageInput.files;

    for(let i = 0; i < files.length; i++){

        const file = files[i];

        // Only allow image files
        if(!file.type.startsWith("image/")){
            continue;
        }

        const reader = new FileReader();

        reader.onload = function(e){

            // Create image card
            const card = document.createElement("div");
            card.className = "imageCard";

            // Create image element
            const img = document.createElement("img");
            img.src = e.target.result;

            // Create download button
            const downloadBtn = document.createElement("button");
            downloadBtn.className = "downloadBtn";
            downloadBtn.textContent = "Download";

            // Download function
            downloadBtn.onclick = function(){

                const link = document.createElement("a");
                link.href = img.src;
                link.download = file.name;
                link.click();
            };

            // Add elements to card
            card.appendChild(img);
            card.appendChild(downloadBtn);

            // Add card to gallery
            gallery.appendChild(card);
        };

        reader.readAsDataURL(file);
    }

});