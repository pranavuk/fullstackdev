// Import required packages
const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const session = require("express-session");
const path = require("path");

const app = express();

// Middleware to parse form data
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static files (HTML, CSS)
app.use(express.static(__dirname));

// Session middleware (used to keep user logged in)
app.use(session({
    secret: "secretkey",
    resave: false,
    saveUninitialized: true
}));

// Connect to MongoDB
mongoose.connect("mongodb://127.0.0.1:27017/usersDB");

// Create schema for users
const userSchema = new mongoose.Schema({
    name: String,
    email: String,
    password: String
});

// Create model
const User = mongoose.model("User", userSchema);



// ----------------------
// REGEX VALIDATION RULES
// ----------------------

// Name must contain only letters and spaces and be at least 3 characters
const nameRegex = /^[A-Za-z ]{3,}$/;

// Basic email validation
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Password must contain:
// at least one uppercase letter
// at least one lowercase letter
// at least one number
// minimum 6 characters
const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{6,}$/;



// ----------------------
// ROUTES
// ----------------------

// Default route → signin page
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "signin.html"));
});

// Signup page
app.get("/signup", (req, res) => {
    res.sendFile(path.join(__dirname, "signup.html"));
});


// User Home Page
app.get("/home", (req, res) => {

    // If user not logged in redirect to login
    if (!req.session.user) {
        return res.redirect("/");
    }

    // Display user's name
    res.send(`
    <link rel="stylesheet" href="/style.css">
    <div class="container">
        <h1>Welcome ${req.session.user.name}</h1>
        <a href="/logout">Logout</a>
    </div>
    `);
});


// ----------------------
// SIGNUP
// ----------------------

app.post("/signup", async (req, res) => {

    const { name, email, password } = req.body;

    // Validate name
    if (!nameRegex.test(name)) {
        return res.send("Invalid name. Use only letters and minimum 3 characters.");
    }

    // Validate email
    if (!emailRegex.test(email)) {
        return res.send("Invalid email format.");
    }

    // Validate password strength
    if (!passwordRegex.test(password)) {
        return res.send("Password must contain uppercase, lowercase, number and be at least 6 characters.");
    }

    // Check if email already exists
    const existingUser = await User.findOne({ email });

    if (existingUser) {
        return res.send("User already exists.");
    }

    // Create new user
    const user = new User({
        name,
        email,
        password
    });

    // Save user to database
    await user.save();

    // Redirect to login page
    res.redirect("/");
});



// ----------------------
// SIGNIN
// ----------------------

app.post("/signin", async (req, res) => {

    const { email, password } = req.body;

    // Find user in database
    const user = await User.findOne({ email, password });

    // If no user found
    if (!user) {
        return res.send("Invalid email or password.");
    }

    // Store user session
    req.session.user = user;

    // Redirect to home page
    res.redirect("/home");
});



// ----------------------
// LOGOUT
// ----------------------

app.get("/logout", (req, res) => {

    // Destroy session
    req.session.destroy();

    // Redirect to login
    res.redirect("/");
});



// Start server
app.listen(3000, () => {
    console.log("Server running on port 3000");
});